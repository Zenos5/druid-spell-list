let firstlevel = [
  {
    id: 1,
    name: "Animal Friendship",
    range: "30 feet",
    castingTime: "1 action",
    duration: "24 hours",
    components: "Verbal, Somatic, Material (a morsel of food)",
    effect: "This spell lets you convince a beast that you mean it no harm. Choose a beast that you can see within range. It must see and hear you. If the beast's Intelligence is 4 or higher, the spell fails. Otherwise, the beast must succeed on a Wisdom saving throw or be charmed by you for the spell's duration. If you or one of your companions harms the target, the spells ends."
  },
  {
    id: 2,
    name: "Charm Person",
    range: "30 feet",
    castingTime: "1 action",
    duration: "1 hour",
    components: "Verbal, Somatic",
    effect: "You attempt to charm a humanoid you can see within range. It must make a wisdom saving throw, and does so with advantage if you or your companions are fighting it. If it fails the saving throw, it is charmed by you until the spell ends or until you or your companions do anything harmful to it. The charmed creature regards you as a friendly acquaintance. When the spell ends, the creature knows it was charmed by you."
  },
  {
    id: 3,
    name: "Create or Destroy Water",
    range: "30 feet",
    castingTime: "1 action",
    duration: "Instantaneous",
    components: "Verbal, Somatic",
    effect: "Create Water: You create up to 10 gallons of clean water within range in an open container. Alternatively, the water falls as rain in a 30-foot cube within range. Destroy Water: You destroy up to 10 gallons of water in an open container within range. Alternatively, you destroy fog in a 30-foot cube within range."
  },
  {
    id: 4,
    name: "Cure Wounds",
    range: "Touch",
    castingTime: "1 action",
    duration: "Instantaneous",
    components: "Verbal, Somatic",
    effect: "A creature you touch regains a number of hit points equal to 1d8 + your spellcasting ability modifier. This spell has no effect on undead or constructs."
  },
  {
    id: 5,
    name: "Detect Magic",
    range: "Self",
    castingTime: "1 action",
    duration: "Up to 10 minutes (Concentration)",
    components: "Verbal, Somatic",
    effect: "For the duration, you sense the presence of magic within 30 feet of you. If you sense magic in this way, you can use your action to see a faint aura around any visible creature or object in the area that bears magic, and you learn its school of magic, if any. The spell can penetrate most barriers, but it is blocked by 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood or dirt."
  },
  {
    id: 6,
    name: "Detect Poison and Disease",
    range: "Self",
    castingTime: "1 action",
    duration: "Up to 10 minutes (Concentration)",
    components: "Verbal, Somatic",
    effect: "For the duration, you can sense the presence and location of poisons, poisonous creatures, and diseases within 30 feet of you. You also identify the kind of poison, poisonous creature, or disease in each case. The spell can penetrate most barriers, but it is blocked by 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood or dirt."
  },
  {
    id: 7,
    name: "Entangle",
    range: "90 feet",
    castingTime: "1 action",
    duration: "Up to 1 minute (Concentration)",
    components: "Verbal, Somatic",
    effect: "Grasping weeds and vines sprout from the ground in a 20-foot square starting form a point within range. For the duration, these plants turn the ground in the area into difficult terrain. A creature in the area when you cast the spell must succeed on a strength saving throw or be restrained by the entangling plants until the spell ends. A creature restrained by the plants can use its action to make a Strength check against your spell save DC. On a success, it frees itself. When the spell ends, the conjured plants wilt away."
  },
  {
    id: 8,
    name: "Faerie Fire",
    range: "60 feet",
    castingTime: "1 action",
    duration: "Up to 1 minute (Concentration)",
    components: "Verbal",
    effect: "Each object in a 20-foot cube within range is outlined in blue, green, or violet light (your choice). Any creature in the area when the spell is cast is also outlined in light if it fails a dexterity saving throw. For the duration, objects and affected creatures shed dim light in a 10-foot radius. Any attack roll against an affected creature or object has advantage if the attacker can see it, and the affected creature or object can't benefit from being invisible."
  },
  {
    id: 9,
    name: "Fog Cloud",
    range: "120 feet",
    castingTime: "1 action",
    duration: "Up to 1 hour (Concentration)",
    components: "Verbal",
    effect: "You create a 20-foot-radius sphere of fog centered on a point within range. The sphere spreads around corners, and its area is heavily obscured. It lasts for the duration or until a wind of moderate or greater speed (at least 10 miles per hour) disperses it."
  },
  {
    id: 10,
    name: "Goodberry",
    range: "Touch",
    castingTime: "1 action",
    duration: "Instantaneous",
    components: "Verbal, Somatic",
    effect: "Up to ten berries appear in your hand and are infused with magic for the duration. A creature can use its action to eat one berry. Eating a berry restores 1 hit point, and the berry provides enough nourishment to sustain a creature for one day. The berries lose their potency if they have not been consumed within 24 hours of the casting of this spell."
  },
  {
    id: 11,
    name: "Healing Word",
    range: "60 feet",
    castingTime: "1 bonus action",
    duration: "Instantaneous",
    components: "Verbal",
    effect: "A creature of your choice that you can see within range regains hit points equal to 1d4 + your spellcasting ability modifier. This spell has no effect on undead or constructs."
  },
  {
    id: 12,
    name: "Jump",
    range: "Touch",
    castingTime: "1 action",
    duration: "1 minute",
    components: "Verbal, Somatic",
    effect: "You touch a creature. The creature's jump distance is tripled until the spell ends."
  },
  {
    id: 13,
    name: "Longstrider",
    range: "Touch",
    castingTime: "1 action",
    duration: "1 minute",
    components: "Verbal, Somatic",
    effect: "You touch a creature. The target's speed increases by 10 feet until the spell ends."
  },
  {
    id: 14,
    name: "Purify Food and Drink",
    range: "10 feet",
    castingTime: "1 action",
    duration: "Instantaneous",
    components: "Verbal, Somatic",
    effect: "All nonmagical food and drink within a 5-foot radius sphere centered on a point of your choice within range is purified and rendered free of poison and disease."
  },
  {
    id: 15,
    name: "Speak with Animals",
    range: "Self",
    castingTime: "1 action",
    duration: "10 minutes",
    components: "Verbal, Somatic",
    effect: "You gain the ability to comprehend and verbally communicate with beasts for the duration. The knowledge and awareness of many beasts is limited by their intelligence, but at a minimum, beasts can give you information about nearby locations and monsters, including whatever they can perceive or have perceived within the past day. You might be able to persuade a beast to perform a small favor for you, at the DM's discretion."
  },
  {
    id: 16,
    name: "Thunderwave",
    range: "Self",
    castingTime: "1 action",
    duration: "Instantaneous",
    components: "Verbal, Somatic",
    effect: "A wave of thunderous force sweeps out from you. Each creature in a 15-foot cube originating from you must make a constitution saving throw. On a failed save, a creature takes 2d8 thunder damage and is pushed 10 feet away from you. On a successful save, the creature takes half as much damage and isn't pushed. In addition, unsecured objects that are completely within the area of effect are automatically pushed 10 feet away from you by the spell's effect, and the spell emits a thunderous boom audible out to 300 feet."
  }
]

export default firstlevel;

