<template>
<div class="wrapper">
  <div class="spells">
    <div class="spell" v-for="spell in firstLevelList" :key="spell.id">
      <div class="info">
        <h1>{{spell.name}}</h1>
        <p>Range: {{spell.range}}</p>
        <p>Casting Time: {{spell.castingTime}}</p>
        <p>Duration: {{spell.duration}}</p>
        <p>Components: {{spell.components}}</p>
      </div>
      <div class="description">
        <h2>{{spell.effect}}</h2>
      </div>
    </div>
  </div>
</div>
</template>

<script>
export default {
  name: 'FirstLevelList',
  props: {
    firstLevelList: Array
  },
}
</script>

<style scoped>
.wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
}

.spells {
  margin-top: 20px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}

.spell {
  margin: 10px;
  margin-top: 50px;
  width: 80%;
}

.info {
  background: #800000;
  color: #FFF;
  padding: 10px 30px;
  height: 230px;
}

.description {
  background: #CFECEC;
  color: #000;
  display: flex;
}

.auto {
  margin-left: auto;
}
</style>

