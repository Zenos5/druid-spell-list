<template>
<div class="wrapper">
  <div class="cantrips">
    <div class="cantrip" v-for="cantrip in cantripList" :key="cantrip.id">
      <div class="info">
        <h1>{{cantrip.name}}</h1>
        <p>Range: {{cantrip.range}}</p>
        <p>Casting Time: {{cantrip.castingTime}}</p>
        <p>Duration: {{cantrip.duration}}</p>
        <p>Components: {{cantrip.components}}</p>
      </div>
      <div class="description">
        <h2>{{cantrip.effect}}</h2>
      </div>
    </div>
  </div>
</div>
</template>

<script>
export default {
  name: 'CantripList',
  props: {
    cantripList: Array
  },
}
</script>

<style scoped>
.wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
}

.cantrips {
  margin-top: 20px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}

.cantrip {
  margin: 10px;
  margin-top: 50px;
  width: 80%;
}

.info {
  background: #827839;
  color: #FFF;
  padding: 10px 30px;
  height: 230px;
}

.description {
  background: #CFECEC;
  color: #000;
  display: flex;
}

.auto {
  margin-left: auto;
}
</style>

