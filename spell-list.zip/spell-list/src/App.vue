<template>
  <div id="app">
    <div class="header">
      <h1>Druid Spell List</h1>
      <div id="nav">
        <router-link to="/">Home</router-link> |
        <router-link to="/level1">1st-Level</router-link> |
        <router-link to="/level2">2nd-Level</router-link> 
      </div>
    </div>
    <div class="content">
      <router-view />
    </div>
    <div class="footer">
      <a href="https://github.com/Zenos5/druid-spell-list">Github Repository</a>
    </div>
  </div>
</template>

<style>
body {
  margin: 0px;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.header {
  display: flex;
  justify-content: space-between;
  background: #347C2C;
  padding: 10px 100px;
  color: white;
}

.footer {
  display: flex;
  justify-content: space-between;
  background: #C0C0C0;
  padding: 10px 100px;
  color: white;
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #fff;
}

#nav a.router-link-exact-active {
  color: #FFC300;
}

.content {
  padding: 10px 100px;
}
</style>

