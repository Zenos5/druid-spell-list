let cantrips = [
  {
    id: 1,
    name: "Druidcraft",
    range: "30 feet",
    castingTime: "1 action",
    duration: "Instantaneous",
    components: "Verbal, Somatic",
    effect: "Can predict weather (next 24 hrs), make a flower blossom, a seed pod open, or a leaf bud, create a harmless sensory effect in a 5 ft cube, and can light or snuff out a fire."
  },
  {
    id: 2,
    name: "Guidance",
    range: "Touch",
    castingTime: "1 action",
    duration: "Up to 1 minute (Concentration)",
    components: "Verbal, Somatic",
    effect: "Touch 1 willing creature. Once before spell ends, target can roll 1d4 and add the number rolled to one ability check of it's choice. Can roll dice before/after ability check."
  },
  {
    id: 3,
    name: "Mending",
    range: "Touch",
    castingTime: "1 minute",
    duration: "Instantaneous",
    components: "Verbal, Somatic, Materials (2 Lodestones)",
    effect: "Repairs a single break or tear in an object you touch.  Physically repairs up to 1 ft."
  },
  {
    id: 4,
    name: "Poison Spray",
    range: "10 feet",
    castingTime: "1 action",
    duration: "Instantaneous",
    components: "Verbal, Somatic",
    effect: "Project a puff of noxious gas from your palm. Constitution saving throw or take 1d12 damage."
  },
  {
    id: 5,
    name: "Produce Flame",
    range: "Self",
    castingTime: "1 action",
    duration: "10 minutes",
    components: "Verbal, Somatic",
    effect: "A flickering flame appears in your hand. The flame remains there for the duration and harms neither you nor your equipment. Bright light 10 ft radius and dim light 10 ft beyond that. Attacks by hurling it up to 30 ft away. Once attack with it, spell ends. Deals 1d8 damage."
  },
  {
    id: 6,
    name: "Resistance",
    range: "Touch",
    castingTime: "1 action",
    duration: "Up to 1 minute (Concentration)",
    components: "Verbal, Somatic, Material (a Mini Cloak)",
    effect: "Touch one willing creature. Once before the spell ends, the target can roll a d4 and add the number rolled to one saving throw of its choice. It can roll the die before or after making the saving throw."
  },
  {
    id: 7,
    name: "Shillelagh",
    range: "Touch",
    castingTime: "1 bonus action",
    duration: "1 minute",
    components: "Verbal, Somatic, Material (wooden club or staff)",
    effect: "The wood of a club or a quarterstaff you are holding is imbued with nature's power. For the duration, you can use your spellcasting ability instead of Strength for the attack and damage rolls of melee attacks using that weapon, and the weapon's damage die becomes a d8. The weapon also becomes magical, if it isn't already."
  }
]

export default cantrips;

