import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import cantrips from "./spells-cantrips.js"
import firstlevel from "./spells-level1.js"
import secondlevel from "./spells-level2.js"

Vue.config.productionTip = false;

let data = {
  cantripList: cantrips,
  firstLevelList: firstlevel,
  secondLevelList: secondlevel
}

new Vue({
  router,
  data,
  render: h => h(App)
}).$mount("#app");
